package com.EI_Assignment;

class ApparelProduct extends Product {
    public ApparelProduct(String name, double price, boolean available) {
        super(name, price, available);
    }
}
