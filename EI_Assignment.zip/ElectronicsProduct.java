package com.EI_Assignment;

class ElectronicsProduct extends Product {
    public ElectronicsProduct(String name, double price, boolean available) {
        super(name, price, available);
    }
}
