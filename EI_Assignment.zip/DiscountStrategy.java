package com.EI_Assignment;

interface DiscountStrategy {
    double applyDiscount(double price, int quantity);
}
